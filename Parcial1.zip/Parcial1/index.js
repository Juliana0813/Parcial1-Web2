import express from 'express';
import { routerStudents } from './routes/index.js'; 

const app = express();

app.use(express.json()); 

app.use((req, res, next) => {
    console.log('Middleware de registro de acceso'); 
    next();
});

routerStudents(app); 

app.listen(3000, () => {
    console.log('Servidor corriendo en el puerto 3000');
});