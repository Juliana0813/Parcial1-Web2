import express from "express";
import { read, write } from './src/utils/files.js'; 
import dayjs from 'dayjs';
import fs from 'fs';

export const studentsFileRouter = express.Router();


const accessLogMiddleware = (req, res, next) => {
    const timestamp = dayjs().format('DD-MM-YYYY HH:mm:ss');
    const method = req.method;
    const path = req.path;
    const headers = JSON.stringify(req.headers);

    
    const logLine = `${timestamp} [${method}] [${path}] [${headers}]\n`;


    fs.appendFile('access_log.txt', logLine, (err) => {
        if (err) {
            console.error("Error al escribir en el archivo de log:", err);
        }
    });

    next(); 
};


const addMetadataMiddleware = (req, res, next) => {
    const timestamp = dayjs().format('HH:mm DD-MM-YYYY');
    req.body.ip = req.ip; 

    if (req.method === 'POST') {
        req.body.created_at = timestamp; 
    } else if (req.method === 'PUT') {
        req.body.updated_at = timestamp; 
    }

    next(); 
};


studentsFileRouter.get("/", accessLogMiddleware, (req, res) => {
    const students = read();

    const { filter, limit } = req.query;
    let filteredStudents = students;

    
    if (filter) {
        const [key, value] = filter.split(':'); 
        filteredStudents = students.filter(student => student[key] === value);
    }

    
    if (limit) {
        const limitNumber = parseInt(limit, 10);
        if (!isNaN(limitNumber)) {
            filteredStudents = filteredStudents.slice(0, limitNumber);
        }
    }

    res.json(filteredStudents);
});


studentsFileRouter.post('/', accessLogMiddleware, addMetadataMiddleware, (req, res) => {
    const students = read(); 
    const student = {
        ...req.body,
        id: students.length + 1 
    };
    students.push(student);
    write(students); 
    res.status(201).json(students);
});


studentsFileRouter.put("/update-field", accessLogMiddleware, addMetadataMiddleware, (req, res) => {
    const { field, value } = req.body; 
    const students = read(); 

    if (!field || value === undefined) {
        return res.status(400).json({ error: "Se requiere un campo y un valor para actualizar." });
    }

    
    const updatedAt = dayjs().format('HH:mm DD-MM-YYYY');

    students.forEach(student => {
        student[field] = value; 
        student.updated_at = updatedAt; 
    });

    write(students); 

    res.json({ message: "Campo actualizado en todos los registros.", updatedStudents: students });
});