import express from 'express';
import { studentsFileRouter } from './students.file.router.js'; 

const router = express.Router();

router.use("/file/students", studentsFileRouter); 

export function routerStudents(app) {
    app.use("/api/v1", router);
}