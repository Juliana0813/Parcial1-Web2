import fs from 'fs';

const FILENAME = 'students.json'; 

function read() {
    try {
        const data = fs.readFileSync(FILENAME, 'utf-8'); 
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error al leer el archivo ${FILENAME}:`, error);
        return []; 
    }
}

function write(data) {
    try {
        fs.writeFileSync(FILENAME, JSON.stringify(data, null, 2)); 
    } catch (error) {
        console.error(`Error al escribir en el archivo ${FILENAME}:`, error);
    }
}

export {
    read,
    write
};